class MODEL:
    Paddle = "pp_structure_v2"
    PEK = "pdf_extract_kit"


class AtomicModel:
    Layout = "layout"
    MFD = "mfd"
    MFR = "mfr"
    OCR = "ocr"
    Table = "table"
    LangDetect = "langdetect"
