class MakeMode:
    MM_MD = "mm_markdown"
    NLP_MD = "nlp_markdown"
    STANDARD_FORMAT = "standard_format"


class DropMode:
    WHOLE_PDF = "whole_pdf"
    SINGLE_PAGE = "single_page"
    NONE = "none"
    NONE_WITH_REASON = "none_with_reason"
