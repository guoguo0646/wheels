def dict_to_list(input_dict):
    items_list = []
    for _, item in input_dict.items():
        items_list.append(item)
    return items_list
